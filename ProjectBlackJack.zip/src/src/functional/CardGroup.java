package functional;

import java.util.*;

public class CardGroup {

	private ArrayList<Card> cards = new ArrayList<Card>();

	public void initFullDeck() {
		this.cards.clear();
		String[] ranks = { "Ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King" };
		int[] rankValues = { 11, 2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 10, 10 };

		String[] suits = { "Clubs", "Diamonds", "Hearts", "Spades" };

		for (int i = 0; i < ranks.length; i++) {
			for (int j = 0; j < suits.length; j++) {
				this.cards.add(new Card(ranks[i], suits[j], rankValues[i]));
			}
		}
	}

	public Card takeCard() { // Ia o carte de deasupra grupului array de carti si o returneaza

		if (this.cards.size() < 1) {
			System.out.println("Eroare: Nu mai sunt carti!");
			System.exit(0);
		}
		return this.cards.remove(this.cards.size() - 1);
	}

	public void shuffle() {
		long seed = System.nanoTime();

		// Implementarea asta trece prin lista din spate in fata, de la ultimul element
		// pana la al doilea, in timp ce in mod repetat face swap cu un element selectat
		// aleatoriu la "pozitia curenta"
		Collections.shuffle(this.cards, new Random(seed));
	}

	public int getTotalValue() {
		int totalValue = 0;
		for (int i = 0; i < this.cards.size(); i++)
			totalValue += this.cards.get(i).value;
		return totalValue;
	}

	public int getNumAces() {
		int numAces = 0;
		for (int i = 0; i < this.cards.size(); i++)
			if (this.cards.get(i).rank == "Ace")
				numAces++;
		return numAces;
	}

	public int getCount() {
		return this.cards.size();
	}

	public void print() {
		for (int i = 0; i < this.cards.size(); i++) {
			this.cards.get(i).print();
		}
	}

	public void addCard(Card card) {
		cards.add(card);
	}

	public void setCard(int pos, Card card) {
		cards.set(pos, card);
	}

	public Card getCard(int pos) {
		return cards.get(pos);
	}

}
