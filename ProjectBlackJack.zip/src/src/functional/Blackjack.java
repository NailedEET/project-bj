package functional;

import javax.swing.JFrame;

@SuppressWarnings("serial")
public class Blackjack extends JFrame {

	private CardGroup deck, dealerCards, playerCards; // Declarari variabile:
	private Card dealerHiddenCard; // Cartea ascunsa a dealerului.

	private double balance = 0.0, betAmount; // Setarea initiala a banilor
	private int roundCount = 0; // Suma pariata de jucator, si numarul de runde.

	public double deal(double betAmount) throws IllegalArgumentException {

		if (betAmount > balance) { // Daca suma pariata este mai mare decat banii ce ii are jucatorul
			throw new IllegalArgumentException("Eroare: Ai pariat mai multi bani decat detii!");
		}
		balance -= betAmount; // Scade suma de pariu din total

		// Initializare jucator / dealer card arrays
		dealerCards = new CardGroup();
		playerCards = new CardGroup();

		dealerHiddenCard = deck.takeCard(); // Ia o carte de deasupra deckului pentru dealer dar ascunsa
		dealerCards.addCard(new Card("", "", 0)); // Adauga carte cu fata in jos la dealer
		dealerCards.addCard(deck.takeCard()); // Adauga carte de deasupra deckului la dealer

		// Adauga doua carti de deasupra pachetului in mana jucatorului
		playerCards.addCard(deck.takeCard());
		playerCards.addCard(deck.takeCard());

		this.betAmount = betAmount;

		return balance;
	}

	public void getTakeCard() {
		playerCards.addCard(deck.takeCard());
	}

	public void initDeck() {
		deck = new CardGroup();
	}

	public void setRoundCount() {
		roundCount = 0;
	}

	public void playerWins() {
		balance += betAmount * 2;
	}

	public void nobodyWins() {
		balance += betAmount;
	}

	public double getBetAmount() {
		return betAmount;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public double getBalance() {
		return balance;
	}

	public boolean increaseRoundCount() {
		roundCount++;

		if (roundCount >= 5) {
			deck.initFullDeck();
			deck.shuffle();
			roundCount = 0;
			return true;
		}

		return false;
	}

	public CardGroup getPlayerCards() {
		return playerCards;
	}

	public CardGroup getDealerCards() {
		return dealerCards;
	}

	public Card getDealerHiddenCard() {
		return dealerHiddenCard;
	}

	public CardGroup getDeck() {
		return deck;
	}
}