package functional;
//

public class Card { // Clasa asta este creata pentru toate cartile si contine informatii pentru
					// fiecare in parte
	// Variabile pentru rank, suit, value
	public String rank = "", suit = "";
	public int value = 0;

	Card(String r, String s, int v) { // Constructor - initializeaza valorile
		this.rank = r;
		this.suit = s;
		this.value = v;
	}

	public void print() { // printeaza informatii despre carte
		System.out.printf("%s of %s, value %d\n", this.rank, this.suit, this.value);
	}

	public String getFileName() { // Preia numele imaginii si il genereaza catre cartea corespunzatoare
		if (value == 0) // Daca asta este cartea dealerului cu fata in jos (valoare 0)
			return "cardImages/backCover.png";
		return String.format("cardImages/%s/%s.png", this.suit, this.rank);
	}
}
