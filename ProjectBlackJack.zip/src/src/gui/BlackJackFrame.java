package gui;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import functional.Blackjack;
import sun.audio.AudioPlayer;
import sun.audio.AudioStream;

@SuppressWarnings("serial")
public class BlackJackFrame extends JFrame {

	private Blackjack blackjack;

	private GameFrame gameFrame;
	private MainMenu menuFrame;
	

	public BlackJackFrame() {
		gameFrame = new GameFrame();
		menuFrame = new MainMenu();
		blackjack = new Blackjack();
		
		
		menuFrame.setBlackjackFrame(this);
		gameFrame.setMasterFrame(this);
		
	}

	public void newGame() {
		menuFrame.setVisible(false);
		gameFrame.setVisible(true);
		
		
		
	}

	public void start() {
		playMusic("BlackJackSound.wav");

		gameFrame.initGuiObjects();

		menuFrame.setVisible(true);
		gameFrame.setVisible(false);

	}

	public void playMusic(String filepath) {

		InputStream music;
		try {
			music = new FileInputStream(new File(filepath));
			AudioStream audios = new AudioStream(music);
			AudioPlayer.player.start(audios);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Eroare: Codul suporta doar fisiere .wav"); // Mesaj in caz ca formatul
																							// fisierului audio nu este
																							// acceptat
		}
	}

	public double deal(int betAmount) {
		return blackjack.deal(betAmount);
	}

	public Blackjack getBlackjack() {
		return blackjack;
	}
}
