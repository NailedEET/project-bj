package gui;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import functional.Blackjack;

@SuppressWarnings("serial")
public class GameFrame extends JFrame {

	// Crearea elemenelor GUI din Window Builder
	private JTextField tfBalance;
	private JLabel lblInitialBalance;
	private JButton btnNewGame;
	private JButton btnEndGame;
	private JTextField tfBetAmount;
	private JLabel lblEnterBet;
	private JButton btnDeal;
	private JLabel lblCurrentBalance;
	private JLabel lblBalanceAmount;
	private JLabel lblDealer;
	private JLabel lblPlayer;
	private JButton btnHit;
	private JButton btnStand;
	private JLabel lblBetAmount;
	private JLabel lblBetAmountDesc;
	private JLabel lblInfo;
	private JButton btnContinue;
	private JLabel lblShuffleInfo = null;

	private BlackJackFrame masterFrame;

	private CardGroupPanel dealerCardPanel;
	private CardGroupPanel playerCardPanel;

	public GameFrame() {
		setTitle("BlackJack");
		setSize(900, 700);
		setLocationRelativeTo(null);
		setLayout(null);
		setResizable(false);

		ImagePanel bgImagePanel = new ImagePanel("background.png");
		bgImagePanel.setBounds(0, 0, this.getWidth(), this.getHeight());
		setContentPane(bgImagePanel);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public void initGuiObjects() {
		btnNewGame = new JButton("Incepe"); // Butonul pentru a incepe jocul
		btnNewGame.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				newGame(); // Incepe jocul
			}
		});
		btnNewGame.setBounds(20, 610, 99, 50);
		getContentPane().add(btnNewGame);

		btnEndGame = new JButton("Iesi din Joc"); // Butonul de 'Exit' inchide programul										
		btnEndGame.setEnabled(false);
		btnEndGame.setBounds(121, 610, 99, 50);
		btnEndGame.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		getContentPane().add(btnEndGame);

		tfBalance = new JTextField();
		tfBalance.setText("100");
		tfBalance.setBounds(131, 580, 89, 28);
		getContentPane().add(tfBalance);
		tfBalance.setColumns(10);

		lblInitialBalance = new JLabel("Introdu Suma:");
		lblInitialBalance.setFont(new Font("Arial", Font.BOLD, 13));
		lblInitialBalance.setForeground(Color.WHITE);
		lblInitialBalance.setBounds(30, 586, 150, 16);
		getContentPane().add(lblInitialBalance);
	}

	public void showBetGui() {

		btnEndGame.setEnabled(true);

		lblCurrentBalance = new JLabel("Banii Curenti:");
		lblCurrentBalance.setHorizontalAlignment(SwingConstants.CENTER);
		lblCurrentBalance.setFont(new Font("Arial", Font.BOLD, 16));
		lblCurrentBalance.setForeground(Color.WHITE);
		lblCurrentBalance.setBounds(315, 578, 272, 22);
		getContentPane().add(lblCurrentBalance);

		lblBalanceAmount = new JLabel();
		lblBalanceAmount.setText(String.format("$%.2f", masterFrame.getBlackjack().getBalance()));
		lblBalanceAmount.setForeground(Color.ORANGE);
		lblBalanceAmount.setFont(new Font("Arial", Font.BOLD, 40));
		lblBalanceAmount.setHorizontalAlignment(SwingConstants.CENTER);
		lblBalanceAmount.setBounds(315, 600, 272, 50);
		getContentPane().add(lblBalanceAmount);

		lblInfo = new JLabel("Te rog introdu o suma, si apasa 'Pariaza'");
		lblInfo.setBackground(Color.ORANGE);
		lblInfo.setOpaque(false);
		lblInfo.setForeground(Color.ORANGE);
		lblInfo.setFont(new Font("Arial", Font.BOLD, 16));
		lblInfo.setHorizontalAlignment(SwingConstants.CENTER);
		lblInfo.setBounds(290, 482, 320, 28);
		getContentPane().add(lblInfo);

		tfBetAmount = new JTextField();
		tfBetAmount.setText("10");
		tfBetAmount.setBounds(790, 580, 89, 28);
		getContentPane().add(tfBetAmount);

		lblEnterBet = new JLabel("Suma Pariata:");
		lblEnterBet.setFont(new Font("Arial", Font.BOLD, 14));
		lblEnterBet.setForeground(Color.WHITE);
		lblEnterBet.setBounds(675, 586, 100, 16);
		getContentPane().add(lblEnterBet);

		btnDeal = new JButton("Pariaza");
		btnDeal.setBounds(679, 610, 200, 50);
		btnDeal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				deal();
			}
		});
		getContentPane().add(btnDeal);
		btnDeal.requestFocus();

		repaint();

	}

	public void deal() { // Cand butonul de 'pariaza' este apasat. Genereaza doua carti pentru jucator,
							// respectiv dealer ( arata doar una din cartile dealerului ) si cere
							// jucatorului sa dea input, sau daca este un outcome instant ( blackjack ), se
							// termina runda.

		if (lblShuffleInfo != null) // La fiecare 5 runde deckul este amestecat iar mesajul asta este printat. Este
									// ascuns cand incepe o runda noua
			getContentPane().remove(lblShuffleInfo);

		int betAmount = 0;
		if (isValidAmount(tfBetAmount.getText()) == true) {
			betAmount = Integer.parseInt(tfBetAmount.getText());
		} else {
			lblInfo.setText("Error: Trebuie sa fie un numar natural!");
			tfBetAmount.requestFocus();
			return;
		}

		try {
			double newBalance = masterFrame.deal(betAmount);
			lblBalanceAmount.setText(String.format("$%.2f", newBalance));
		} catch (IllegalArgumentException e) {
			lblInfo.setText("Eroare: Ai pariat mai multi bani decat detii!"); // Printeaza eroare
			tfBetAmount.requestFocus();
			return;
		}

		tfBetAmount.setEnabled(false);
		btnDeal.setEnabled(false);

		lblInfo.setText("Te rog alege Hit sau Stai");

		lblDealer = new JLabel("Dealer"); // Label pentru dealer
		lblDealer.setForeground(Color.WHITE);
		lblDealer.setFont(new Font("Arial Black", Font.BOLD, 20));
		lblDealer.setBounds(415, 158, 82, 28);
		getContentPane().add(lblDealer);

		lblPlayer = new JLabel("Jucator"); // Label pentru Jucator
		lblPlayer.setForeground(Color.WHITE);
		lblPlayer.setFont(new Font("Arial Black", Font.BOLD, 20));
		lblPlayer.setBounds(415, 266, 90, 28);
		getContentPane().add(lblPlayer);

		btnHit = new JButton("Hit"); // Butonul de Hit
		btnHit.setBounds(290, 515, 140, 35);
		btnHit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				hit(); // Cand e apasat, hit
			}
		});
		getContentPane().add(btnHit);
		btnHit.requestFocus();

		btnStand = new JButton("Stai"); // Butonul de Stai
		btnStand.setBounds(470, 515, 140, 35);
		btnStand.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				stand(); // Cand e apsat, stai
			}
		});
		getContentPane().add(btnStand);

		btnContinue = new JButton("Continua"); // Butonul de Continua
		btnContinue.setEnabled(false);
		btnContinue.setVisible(false);
		btnContinue.setBounds(290, 444, 320, 35);
		btnContinue.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				acceptOutcome();
			}
		});
		getContentPane().add(btnContinue);

		lblBetAmount = new JLabel(); // Arata suma pariata
		lblBetAmount.setText("$" + betAmount);
		lblBetAmount.setHorizontalAlignment(SwingConstants.CENTER);
		lblBetAmount.setForeground(Color.ORANGE);
		lblBetAmount.setFont(new Font("Arial", Font.BOLD, 40));
		lblBetAmount.setBounds(679, 488, 200, 50);
		getContentPane().add(lblBetAmount);

		lblBetAmountDesc = new JLabel("Suma Pariata:"); // Label cu informatiile sumei pariate
		lblBetAmountDesc.setHorizontalAlignment(SwingConstants.CENTER);
		lblBetAmountDesc.setForeground(Color.WHITE);
		lblBetAmountDesc.setFont(new Font("Arial", Font.BOLD, 16));
		lblBetAmountDesc.setBounds(689, 465, 190, 22);
		getContentPane().add(lblBetAmountDesc);

		repaint();

		updateCardPanels();

		simpleOutcomes(); // Verifica outcome automat (ex. blackjack instant)

	}

	public void hit() { // Adauga carte la cartile jucatorului, dupa care verifica rezultatele
		Blackjack b = masterFrame.getBlackjack();
		b.getTakeCard();
		updateCardPanels();

		simpleOutcomes();

	}

	public boolean simpleOutcomes() {
		Blackjack b = masterFrame.getBlackjack();

		boolean outcomeHasHappened = false;
		int playerScore = b.getPlayerCards().getTotalValue(); // Scorul jucatorului in functie de suma cartilor ce le
																// detine
		if (playerScore > 21 && b.getPlayerCards().getNumAces() > 0) // Verifica daca jucatorul are cel putin un As si
																		// trece de
			// 21, scade valoarea asului cu 10.

			playerScore -= 10;

		if (playerScore == 21) {

			b.getDealerCards().setCard(0, b.getDealerHiddenCard()); // Intoarce cartea dealerului cu fata in sus
			updateCardPanels(); // Arata carte noua
			if (b.getDealerCards().getTotalValue() == 21) { // Daca si dealerul are blackjack
				lblInfo.setText("Nu a castigat nimeni!"); // Egalitate
				b.setBalance(b.getBalance() + b.getBetAmount()); // Returneaza suma pariata jucatorului
			} else {
				// Daca doar jucatorul are blackjack
				lblInfo.setText(String.format("Jucatorul are BlackJack! Castigi: $%.2f", 1.5f * b.getBetAmount()));
				b.setBalance(b.getBalance() + b.getBetAmount()); // Adauga castigul la suma de bani a jucatorului
			}
			lblBalanceAmount.setText(String.format("$%.2f", b.getBalance())); // Genereaza suma noua

			outcomeHasHappened = true;
			outcomeHappened(); // Cand se ajunge la un rezultat, arata butonul de continua si incepe o runda
								// noua
		} else if (playerScore > 21) { // Daca jucatorul trece de 21
			lblInfo.setText("Ai trecut de 21! Ai pierdut: $" + b.getBetAmount());
			b.getDealerCards().setCard(0, b.getDealerHiddenCard()); // Intoarce cartea ascunsa a dealerului cu fata in
																	// sus
			updateCardPanels();
			outcomeHasHappened = true;
			outcomeHappened(); // Cand se ajunge la un rezultat, arata butonul de continua si incepe o runda
								// noua

		}
		return outcomeHasHappened;

	}

	public void stand() { // Cand se apasa butonul de 'Stai'
		Blackjack b = masterFrame.getBlackjack();

		if (simpleOutcomes())
			return;

		int playerScore = b.getPlayerCards().getTotalValue(); // Scorul total al jucatorului din cartile ce le detine
		if (playerScore > 21 && b.getPlayerCards().getNumAces() > 0) // Verifica daca jucatorul are cel putin un As si
																		// trece de
			// 21, scade valoarea asului cu 10.
			playerScore -= 10;

		b.getDealerCards().setCard(0, b.getDealerHiddenCard()); // Intoarce cartea ascunsa a dealerului cu fata in sus

		int dealerScore = b.getDealerCards().getTotalValue(); // Scorul total al dealerului din cartile ce le detine

		while (dealerScore < 16) { // Daca mana dealerului < 16 , trebuie sa mai ceara carti pana este > 16
			b.getDealerCards().addCard(b.getDeck().takeCard()); // Adauga o carte de deasupra pachetului
			dealerScore = b.getDealerCards().getTotalValue();
			if (dealerScore > 21 && b.getDealerCards().getNumAces() > 0) // Daca exista un As si totalul > 21, scade 10
				dealerScore -= 10;
		}
		updateCardPanels(); // Arata cartile dealerului

		// Determina rezultatele finale, plateste castigatorii, si printeaza rezultatele
		if (playerScore > dealerScore) { // Player wins
			lblInfo.setText("Jucatorul a Castigat! Castigi: $" + b.getBetAmount());
			b.playerWins();
			lblBalanceAmount.setText(String.format("$%.2f", b.getBalance()));
		} else if (dealerScore == 21) { // Dealer blackjack
			lblInfo.setText("Dealerul are Blackjack! Ai pierdut: $" + b.getBetAmount());
		} else if (dealerScore > 21) { // Dealerul pierde
			lblInfo.setText("Dealerul a trecut de 21! Castigi: $" + b.getBetAmount());
			b.playerWins();
			lblBalanceAmount.setText(String.format("$%.2f", b.getBalance()));
		} else if (playerScore == dealerScore) { // egalitate
			lblInfo.setText("Nu a castigat nimeni!");
			b.nobodyWins();
			lblBalanceAmount.setText(String.format("$%.2f", b.getBalance()));
		} else { // Altfel dealerul castiga
			lblInfo.setText("Dealerul a Castigat! Ai pierdut: $" + b.getBetAmount());
		}
		outcomeHappened(); // Cand se genereaza un rezultat, incheie runda, Arata rezultatele rundei si
							// butonul de 'Continua'

	}

	public void outcomeHappened() {

		btnHit.setEnabled(false);
		btnStand.setEnabled(false);

		// Efecte fancy, label de informatii portocaliu si intarziere la printarea
		// butonului 'Continua' cu 500ms
		lblInfo.setOpaque(true);
		lblInfo.setForeground(Color.RED);
		new Timer().schedule(new TimerTask() {
			@Override
			public void run() {
				btnContinue.setEnabled(true);
				btnContinue.setVisible(true);
				btnContinue.requestFocus();
			}
		}, 500);

	}

	public void acceptOutcome() { // Cand un rezultat este final
		Blackjack b = masterFrame.getBlackjack();

		lblInfo.setOpaque(false);
		lblInfo.setForeground(Color.ORANGE);

		getContentPane().remove(lblDealer);
		getContentPane().remove(lblPlayer);
		getContentPane().remove(btnHit);
		getContentPane().remove(btnStand);
		getContentPane().remove(lblBetAmount);
		getContentPane().remove(lblBetAmountDesc);
		getContentPane().remove(btnContinue);
		getContentPane().remove(dealerCardPanel);
		getContentPane().remove(playerCardPanel);
		lblInfo.setText("Te rog introdu o suma, si apasa 'Pariaza' ");
		tfBetAmount.setEnabled(true);
		btnDeal.setEnabled(true);
		btnDeal.requestFocus();
		repaint();

		if (masterFrame.getBlackjack().getBalance() <= 0) { // Daca ramai fara bani ai optiunea sa mai iei din casa, sau
															// sa inchizi jocul.
			int choice = JOptionPane.showOptionDialog(null,
					"Ai ramas fara bani. Apasa Yes sa primesti inca $100, sau No sa iesi din joc.", "Nu mai ai bani!",
					JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, null, null);

			if (choice == JOptionPane.YES_OPTION) {
				b.setBalance(b.getBalance() + 100);
				lblBalanceAmount.setText(String.format("$%.2f", b.getBalance()));
			} else {
				System.exit(0);
			}
		}

		// Daca trec 5 runde, reinitializeaza deck-ul il amesteca din nou pentru a nu
		// ramane fara carti
		boolean wasShuffled = b.increaseRoundCount();
		if (wasShuffled) {
			lblShuffleInfo = new JLabel("Pachetul a fost amestecat!");
			lblShuffleInfo.setForeground(Color.ORANGE);
			lblShuffleInfo.setFont(new Font("Arial", Font.BOLD, 20));
			lblShuffleInfo.setHorizontalAlignment(SwingConstants.CENTER);
			lblShuffleInfo.setBounds(235, 307, 430, 42);
			getContentPane().add(lblShuffleInfo);
		}
	}

	public void newGame() { // Cand incepe jocul

		Blackjack b = masterFrame.getBlackjack();

		if (isValidAmount(tfBalance.getText()) == true) { // Verifica daca suma este valida
			b.setBalance(Integer.parseInt(tfBalance.getText()));
		} else {
			JOptionPane.showMessageDialog(this, "Suma invalida! Te rog asigura-te ca ai introdus un numar natural.",
					"Eroare", JOptionPane.ERROR_MESSAGE);
			tfBalance.requestFocus();
			return;
		}

		btnNewGame.setEnabled(false);
		tfBalance.setEnabled(false);

		showBetGui(); // Arata optiunile de pariere

		b.setRoundCount();

		b.initDeck(); // initializare deck dealer
		b.getDeck().initFullDeck(); // Adauga toate cartile (default 52 carti)
		b.getDeck().shuffle(); // Amesteca deck

	}

	public void updateCardPanels() { // Printeaza cartile jucatorului si ale dealerului ca imagini
		Blackjack b = masterFrame.getBlackjack();
		if (dealerCardPanel != null) { // Daca sunt deja adaugate, le sterge
			getContentPane().remove(dealerCardPanel);
			getContentPane().remove(playerCardPanel);
		}
		// Creaza si printeaza 2 panouri ( pannels )
		dealerCardPanel = new CardGroupPanel(b.getDealerCards(), 420 - (b.getDealerCards().getCount() * 40), 50, 70,
				104, 10);
		getContentPane().add(dealerCardPanel);
		playerCardPanel = new CardGroupPanel(b.getPlayerCards(), 420 - (b.getPlayerCards().getCount() * 40), 300, 70,
				104, 10);
		getContentPane().add(playerCardPanel);
		repaint();
	}

	public int heightFromWidth(int width) {
		return (int) (1f * width * (380f / 255f));
	}

	public void setMasterFrame(BlackJackFrame masterFrame) {
		this.masterFrame = masterFrame;
	}

	public boolean isValidAmount(String s) { // Verifica daca valorile introduse de jucator la suma de bani si
		// suma de pariu sunt numere naturale.
		try {
			if (Integer.parseInt(s) > 0) // Verifica daca valoarea introdusa este > 0
				return true;
			else
				return false;
		} catch (NumberFormatException e) {
			return false;
		}
	}
	
}
