package main;

import gui.BlackJackFrame;

public class Main {
	public static void main(String[] args) {
		BlackJackFrame mainFrame = new BlackJackFrame();
		mainFrame.start();
	}
}
